public class RemoveDuplicatesFromSortedArray {
    public int removeDuplicates(int[] nums) {
        if(nums.length == 0) return 0;
        int k = 1;
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] != nums[i - 1]) nums[k++] = nums[i];
        }
        return k;
    }
    public static void main(String[] args) {
        System.out.println("Unique elements count: " + new RemoveDuplicatesFromSortedArray().removeDuplicates(new int[]{1,1,2}));
    }
}